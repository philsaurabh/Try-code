# Realtime app source code
To train model for Ubiquity, Run the files serialwise by providing appropriate data folder location.
